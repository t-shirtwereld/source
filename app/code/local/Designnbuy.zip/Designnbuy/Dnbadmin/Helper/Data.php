<?php
class Designnbuy_Dnbadmin_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 