<?php  

class Designnbuy_Dnbadmin_Block_Adminhtml_Dnbadminbackend extends Mage_Adminhtml_Block_Template {
    
}